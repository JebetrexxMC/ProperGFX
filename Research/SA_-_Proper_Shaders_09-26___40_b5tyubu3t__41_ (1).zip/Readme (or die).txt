  __  __ _      __  __           _
 |  \/  (_)    |  \/  |         | | 2026
 | \  / |___  _| \  / | ___   __| |___
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/


=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "Proper Shaders" to your ModLoader folder.

-- Requires Essentials Pack: https://www.mixmods.com.br/2019/06/sa-essentials-pack/
-- Recommended Open Limit Adjuster (or well configured f92la): https://www.mixmods.com.br/2022/10/open-limit-adjuster/
-- If you get an error message regarding shaders or the mod doesn't take effect, try installing (this also helps fix other old mods, games, and programs): https://github.com/BloopSmasher/All-in-One-Runtime-Installer/releases/latest

The mod no longer uses "ProperShaders.ini"; check the "settings" folder.



== INCOMPATIBILITIES AND WARNINGS:

Even though this mod aims to be stable and optimized, it is still an experimental "alpha" version, so don't expect the most stable and optimized thing in the world; there is still a long way to go. Keep following the updates on Patreon (mainly on the Patreon Discord): https://www.patreon.com/djjr

Windowed Mode: Is optional but recommended to fix the game crashing when minimizing. This is not compatible with older versions of Windowed Mode. Download the new version (update it in Essentials Pack), otherwise your game will crash in "ntdll": https://github.com/ThirteenAG/III.VC.SA.WindowedMode/releases

MSAA: The game's original anti-aliasing (MSAA) was replaced by SMAA (an option in the .ini) for technical reasons (there are benefits). "Temporal" is enabled by default; if you want to disable it, or if you experience bugs of image-shakiness, turn it off in "- PostFX.ini".

Resolution: It's not yet compatible with changing resolution during game (it will crash). This will be adapted soon.

Real Skybox: Do not use Real Skybox, otherwise it will cause bugs. It will be included in this mod in the future (better integrated with the sky shader). In any case, you can use volumetric clouds; if your PC is weak, configure it by increasing the downscale, lowering layers etc.

SkyGfx: Disable (; at the beginning of the line) "vehiclePipe" and "buildingPipe" in skygfx1.ini (and others), as this mod replaces them on ProperShaders.ini. Remember that this mod replaces SkyGfx, so it only makes sense to use it if you want the PS2 colors.

Brightness: If the game looks too bright or too dark, adjust "Exposure_Day" in "- PostFX.ini". If you want to faithfully replicate the PS2 graphics using SkyGfx, disable or tweak the "SimulateHDR" setting in that same .ini file. Keep in mind that the "brightness" setting in the in-game menu simply controls the map's ambient color and shading (prelight); "IndirectFloor" in "- Lighting.ini" also highly contributes to world lighting. SimulateHDR also supports LUTs.

Sun/Intense Fog: Some timecycle mods can excessively increase sun brightness and "blow out" the volumetric fog's glow. You can lower "SunIntensity" or "Density"/"DensityMult" in "- Fog.ini" and "- Lighting.ini"

Timecyc: The mod uses some values ​​from the game's "timecyc.dat". It was created using the original file, but that isn't critical, and you can use others if you wish.

ReShade: Enable reverse Z buffer in its options to be compatible with "ReversedDepthBuffer = 1".

SAMP: It is expected to work, but depending on the version and server, bugs may occur that still need to be identified and fixed, such as clouds. Use SAMP Graphic Restore mod.

PedSpec: Not compatible, but technically this mod does the same thing (and will include a shader map to add the shine selectively). If a mod you downloaded requires PedSpec, that indicates an error in the skin mod itself, that PedSpec "unintentionally" fixes. Ask the author to fix it or use this tool: https://drive.google.com/file/d/11nzP5l1l0aPl_DbVXKGOcdxf89lVo6oS/view


== ADJUSTMENTS:

In the "ProperShaders.ini" file, mostly at the top, you can disable this mod's features in case it is incompatible with another mod. If you disable all features in the .ini, this mod will do practically nothing to your game.

In the "(presets)" folder, there are options for higher or lower graphics settings. Simply replace the "ProperShaders.ini" file. By default, medium graphics are used. If your PC is mid-range, I recommend "(3b- medium-high)" or "(4- high)".

Many bugs you'll see related to sun glare and incorrect shadows on surfaces aren't actually bugs from this mod, but rather from the game's own mesh normals! Juse latest Proper Fixes version to fix this and have better compatibility with PBR shadermaps: https://www.mixmods.com.br/2026/06/sa-proper-fixes/

It is recommended to use this mod with the brightness in the menu set to half. It's good to remember that the game's "brightness" is actually just a prelight adjustment (map shading), so you can tweak the game's graphics with that in mind, while the screen brightness is tweaked on the "exposure" in .ini file. The GraphicsTweaker mod is still welcome (but in the future, it will be fully implemented into this one).

It is highly recommended to use this mod along with our "Proper Fixes" mod and other "Proper" mods of ours; but do not download "Proper" mods from websites outside of MixMods, as there are people releasing mods with that name to pretend to be us. "Proper" mods are only officially available on the MixMods website. The RoSA Evolved mod will soon add shadermaps (like normal maps, roughness maps) so the textures react realistically with the lighting. If you are looking for clean and "modern" graphics, like in my demos, don't use SkyGfx and/or use Real Linear Graphics with "DayLightingMult" set to "0.5".

Proper Fixes: Highly recommended to use, specially the most updated version (from 2026 or newer).

API/documentation for modders: https://github.com/MixMods/ProperShadersApiExample



Version: 09-26 (10/09/26 DD/MM/YY)
Public in 01.11.26, FORBIDDEN sharing with non-supporters before this date
--------------------

Author: Junior_Djjr
Co-author: Jéssica Natália
Third party credits: (see "Third Party.txt")


= Special thanks to max supporters: 
Rosset RJ45
Victor Hugo Silveira Gavião
Ricky Dhillon
Raul Silva
pedrxr
iJuanMx7


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====
====   patreon.com/c/djjr            ====

